//-------------------------------------------------------------------
#ifndef __UI_HPP__
#define __UI_HPP__

#define EVENT_DCDCC		10
#define EVENT_EMERGENCY	11

void setupUI();
void loopUI(unsigned long inEvent);

#endif
//-------------------------------------------------------------------
