#define EVENT_EMERGENCY	10

void setupUI();
void loopUI(byte inEvent);

