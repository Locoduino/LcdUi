//-------------------------------------------------------------------
#ifndef __UI_HPP__
#define __UI_HPP__

#define EVENT_EMERGENCY		100
#define EVENT_EMERGENCY_CONFIRM		101

void setupUI();
void loopUI(unsigned long inEvent);

#endif
//-------------------------------------------------------------------
