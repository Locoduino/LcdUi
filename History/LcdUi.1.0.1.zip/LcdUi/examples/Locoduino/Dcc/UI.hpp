#define EVENT_STOP	10

void setupUI();
void loopUI(byte inEvenement);

